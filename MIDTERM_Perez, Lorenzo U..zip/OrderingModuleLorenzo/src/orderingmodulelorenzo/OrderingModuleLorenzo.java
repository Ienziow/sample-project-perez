/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package orderingmodulelorenzo;

/**
 *
 * @author Lorenzo Perez
 */
import javax.swing.JFrame;

public class OrderingModuleLorenzo {
    public static void main(String[] args) {
        // Set LoginFormLorenzo as the main class
        LoginFormLorenzo loginForm = new LoginFormLorenzo();
        loginForm.setVisible(true);
    }
}
